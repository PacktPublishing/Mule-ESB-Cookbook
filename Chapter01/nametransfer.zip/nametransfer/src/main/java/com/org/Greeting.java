package com.org;

public class Greeting {

	
	public String sayHi(String str)
	{
		return "Hello "+str;
	}
}
