import org.mulesoft.dmia.example.InputPojo

InputPojo sample = new InputPojo()
sample.description = "Sample Description"
sample.id = 1000
sample.creationTimestamp = System.currentTimeMillis()
sample.value1 = "Sample Name"
sample.value2 = "Sample un-used value"

return sample